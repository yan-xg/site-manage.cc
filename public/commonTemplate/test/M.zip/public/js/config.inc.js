document.write("<script src='//huijian-kuaidao.kuaidao.cn/kdjs/kd.js'></script>");

function addEventdx(obj, evt, fn) {
    if (obj.attachEvent) {
        obj.attachEvent("on" + evt, fn);
    } else {
        obj.addEventListener(evt, fn, false);
    }
}

addEventdx(window, 'load', function () {
    var all_hjtzxyh = document.querySelectorAll('.hjtzxyh');
 for(var i=0;i<all_hjtzxyh.length;i++){
  all_hjtzxyh[i].addEventListener("click", function(e) {
    interactive.openGreatBear(e, '页面点击发起大熊')
  })
 }
});