$('document').ready(function() {

    $('#close').click(function() {
        $(".msgWrap").remove();
    });


    $('.goTop').click(function() {
        $(window).scrollTop(0);
    });

    var flag = false;

    $(".re-nav-btn").click(function() {
        if (!flag) {
            $(".re-nav-btn").addClass('active');
            //执行方法;
            $('.m-nav-wraper').slideDown();

            flag = true;
        } else {
            $(".re-nav-btn").removeClass('active');
            $('.m-nav-wraper').slideUp();
            flag = false;
        }
    })


});