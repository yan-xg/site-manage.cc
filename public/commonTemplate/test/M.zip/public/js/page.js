$(document).ready(function() {
   function NavScroll(objId, num){
        var offY = $(window).scrollTop();
        var obj  = $(objId);
        var offH = obj.offset().top;
        obj.css('position',"absolute");
        obj.css('top', num);
        $(window).scroll(function() {
         offY = $(window).scrollTop();
         if(offY >= (num + offH - 90)){
           obj.css('top', offY - offH + 200+ "px");
         }else{
           obj.css('top',30 + "px")
         }
       });
     }
     NavScroll('#page-nav', 30);
       $('#page-nav').onePageNav({
         currentClass: 'current',
         changeHash: false,
         scrollSpeed: 350,      //滚动速度
         scrollThreshold: 0.1,  //滚动阈值
         filter: '',
         easing: 'swing',
         begin: function() {
         },
         end: function() {
         },
         scrollChange: function($currentListItem) {
         }
     });
    /* 侧导航返回顶部高亮处理*/
    $('.goTop').click(function(){
        $('#page-nav li').eq(0).addClass('current').siblings().removeClass('current') ;
    });


 });

