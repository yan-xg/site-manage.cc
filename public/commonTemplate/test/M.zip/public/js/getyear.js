var now   = new Date();
var year  = now.getFullYear();
document.write(year);