$(function(){
  var wow = new WOW({
    boxClass: 'wow',
    animateClass: 'animated',
    offset: 0,
    mobile: true,
    live: true
  });
  wow.init();
  var mySwiper = new Swiper ('.home-swiper-container', {
    loop: false,
    speed:300,
    pagination: {
      el: '.home-pagination',
      clickable: true,
    },
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    }
  });
  var swiper1 = new Swiper('.swiper-container1', {
      loop: true,
      speed:2000,
      autoplay: {
          delay: 500,
          disableOnInteraction: false,
        },
      slidesPerView: 2,
      spaceBetween: 20,
      breakpoints: {
      2000: {
        autoplay:false,
        loop:false,
        slidesPerView: 2,
        spaceBetween: 20,
        allowTouchMove: false,
      },
      960: {
        slidesPerView: 1,
        spaceBetween: 20
      }
    },
      // pagination: {
      //   el: '.swiper-pagination',
      //   clickable: true,
      // },
    });
    var swiper2 = new Swiper('.swiper-container2', {
      effect : 'fade',
      loop: true,
      speed:2000,
      spaceBetween: 20,
       autoplay: {
            delay: 500,
            disableOnInteraction: false,
          },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
    var swiper3 = new Swiper('.swiper-container3', {
      loop: true,
      speed:2000,
      autoplay: {
          delay: 500,
          disableOnInteraction: false,
        },
      slidesPerView: 5,
      spaceBetween: 30,
      breakpoints: {
      2000: {
        slidesPerView: 5,
        spaceBetween: 20,
      },
      960: {
        slidesPerView: 3,
        spaceBetween: 10
      }
    },
      // pagination: {
      //   el: '.swiper-pagination',
      //   clickable: true,
      // },
    });
    var swiper4 = new Swiper('.swiper-container4', {
      slidesPerView: 1,
      spaceBetween: 0,
      // pagination: {
      //   el: '.swiper-pagination',
      //   clickable: true,
      // },
    });
    var swiper5 = new Swiper('.swiper-container5', {
      slidesPerView: 3,
      spaceBetween: 20,
      // pagination: {
      //   el: '.swiper-pagination',
      //   clickable: true,
      // },
    });
    var swiper6 = new Swiper('.swiper-container6', {
      loop: true,
      speed:2000,
      autoplay: {
          delay: 500,
          disableOnInteraction: false,
        },
      slidesPerView: 3,
      spaceBetween: 20,
      breakpoints: {
      2000: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      960: {
        slidesPerView: 2,
        spaceBetween: 10
      }
    },
      // pagination: {
      //   el: '.swiper-pagination',
      //   clickable: true,
      // },
    });



















  
  var s3Swiper = new Swiper ('#s3-lb', {
    loop: true,
    effect:'fade',
    slidesPerView :1,
    speed:300,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    navigation: {
      nextEl: '.s3-next',
      prevEl: '.s3-prev',
    },
    pagination: {
      el: '.s3-pagination',
      clickable: true,
    },
  });
  var s4Swiper = new Swiper ('#s4-lb', {
    loop: true,
    loopedSlides: 3,
    slidesPerView: 'auto',
    spaceBetween: 5,
    speed:2000,
    autoplay: {
      delay: 1000,
      disableOnInteraction: false,
    }
  });
  var s5Swiper = new Swiper ('#s5-lb', {
    loop: true,
    loopedSlides: 6,
    slidesPerView :'auto',
    spaceBetween: 20,
    speed:2000,
    autoplay: {
      delay: 0,
      disableOnInteraction: false,
    },
    breakpoints: {
      2000: {
        slidesPerView: 'auto',
        loopedSlides: 6,
        spaceBetween: 20,
      },
      960: {
        slidesPerView :'auto',
        loopedSlides: 6,
        spaceBetween: 5
      }
    },

  });
  var newsSwiper = new Swiper ('#home-news', {
    loop: true,
    slidesPerView: 2,
    spaceBetween: 30,
    speed:1000,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    breakpoints: {
      2000: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      960: {
        slidesPerView: 1,
        spaceBetween: 5
      }
    },

  });



  $('.liuyan-list li').click(function(){
    //console.log($(this).text())
    var val = $(this).find('span').text();
    $('.liuyan-content').val(val)
  })




  $('.shengming-btn').click(function(){
    $('.shengming-wraper').fadeOut();
  });






})