<?php  if(!defined('DEDEINC')) exit('dedecms');
/**
 * 扩展小助手
 *
 * @version        $Id: extend.helper.php 1 13:58 2010年7月5日Z tianya $
 * @package        DedeCMS.Helpers
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

/**
 *  返回指定的字符
 *
 * @param     string  $n  字符ID
 * @return    string
 */
if ( ! function_exists('ParCv'))
{
    function ParCv($n)
    {
        return chr($n);
    }
}


/**
 *  显示一个错误
 *
 * @return    void
 */
if ( ! function_exists('ParamError'))
{
    function ParamError()
    {
        ShowMsg('对不起，你输入的参数有误！','javascript:;');
        exit();
    }
}

/**
 *  默认属性
 *
 * @param     string  $oldvar  旧的值
 * @param     string  $nv      新值
 * @return    string
 */
if ( ! function_exists('AttDef'))
{
    function AttDef($oldvar, $nv)
    {
        return empty($oldvar) ? $nv : $oldvar;
    }
}


/**
 *  返回Ajax头信息
 *
 * @return     void
 */
if ( ! function_exists('AjaxHead'))
{
    function AjaxHead()
    {
        @header("Pragma:no-cache\r\n");
        @header("Cache-Control:no-cache\r\n");
        @header("Expires:0\r\n");
    }
}

/**
 *  去除html和php标记
 *
 * @return     string
 */
if ( ! function_exists('dede_strip_tags'))
{
	function dede_strip_tags($str) { 
	    $strs=explode('<',$str); 
	    $res=$strs[0]; 
	    for($i=1;$i<count($strs);$i++) 
	    { 
	        if(!strpos($strs[$i],'>')) 
	            $res = $res.'&lt;'.$strs[$i]; 
	        else 
	            $res = $res.'<'.$strs[$i]; 
	    } 
	    return strip_tags($res);    
	} 
}


function randnum($t)
{
	if($t==1){return rand(20,50);}
	if($t==2){return rand(93,99);}
	if($t==3){return rand(500,800);}
	if($t==4){return rand(1,3);}
}

function randnum2($b,$e)
{
	return rand($b,$e);
}


function dstar()
{    $a=randnum(1);
	 $a%2==0 ? $i='5':$i='4_1';
	 return "<span class='comment-item-star'><span class='real-star comment-stars-width".$i."'></span></span> ";
}

if ( ! function_exists('gettplink2'))
{
	 function gettplink2($ppyd,$jine,$leibie){
	 global $dsql;
	 if($leibie!="" && $ppyd=="" && $jine=="")
		{
		$wheresql="typename='".$leibie."'";
  	    }
		else if($ppyd!="" && $leibie=="" && $jine=="")
		{
		$wheresql="typename = '".$ppyd."'";
		}
		else if($jine!="" && $leibie=="" && $ppyd=="")
		{
		$wheresql="typename = '".$jine."'";
		}
 	 $sql="select * from dede_arctype where $wheresql";
	 $d= $dsql->GetOne($sql);
	 if(empty($d))
	 {
	  $url="javascript:void(0)";
	 }
	 else
	 {$url="<a  style='color:#000;' href='".$d['typedir']."/'>".$d['typename']."</a>";}
	 return $url;
	}
}


function rand_time(){
$start_time =time()-(3600*24*2); 
$end_time = time();
return date('Y-m-d H:i:s', mt_rand($start_time,$end_time));
}



function getip2()
{
$ip2id= round(rand(600000, 2550000) / 10000); 
$ip3id= round(rand(600000, 2550000) / 10000); 
$ip4id= round(rand(600000, 2550000) / 10000); 
$arr_1 = array("218","120","218","66","66","65","218","218","60","60","202","204","66","66","66","59","61","60","222","221","66","59","60","60","66","218","218","62","63","64","66","66","122","211"); 
$randarr= mt_rand(0,count($arr_1)-1); 
$ip1id = $arr_1[$randarr]; 
$ip=$ip1id.".".$ip2id.".".$ip3id.".*"; 
return $ip;
}

function getrand($t)
{
   return $ini=40000-($t*rand($t*100+500,$t*200+500));
}

/**
 *   生成某个范围内的随机时间
 * @param <type> $begintime  起始时间 格式为 Y-m-d H:i:s
 * @param <type> $endtime    结束时间 格式为 Y-m-d H:i:s  
 */
function randomDate($begintime="2010-10-1 00:00:00", $endtime="2013-10-1 00:00:00") {
    $begin = strtotime($begintime);
    $end = $endtime == "" ? mktime() : strtotime($endtime);
    $timestamp = rand($begin, $end);
    return date("Y-m-d", $timestamp);
}

if ( ! function_exists('getybdfield'))//获取当前资讯同项目名称的相同资讯
{
	function getybdfield($typename,$field)
	{
		 global $dsql;
		 $row= $dsql->GetOne("select * from dede_arctype where typename= '$typename'");
		 return $row[$field];
		 
	}
}

if ( ! function_exists('getlitpic'))//获取当前资讯同项目名称的相同资讯
{
	function getlitpic($id)
	{
		 global $dsql;
		 $row= $dsql->GetOne("select * from dede_archives where id= $id");
		 $row2= $dsql->GetOne("select * from dede_addonarticle where aid= $id");
		 if(empty($row2['addslider1'])){
			 $litpic=$row['litpic'];
		 }
		 else{
			 $litpic=$row2['addslider1'];
		 }
		 return $litpic;
		 
	}
}

function erweima($filename)
{
	//引入phpqrcode库文件
    include('phpqrcode.php'); 
    // 二维码数据 
    $data = 'http://192.168.1.1:1820/'.$filename; 
    // 生成的文件名 
    $filename=str_replace('/xm/','',$filename);
    $filename2 = "E:/WWW/2moban.weige.me/qrcode".$filename.".png"; 
    // 纠错级别：L、M、Q、H 
    $errorCorrectionLevel = 'L';  
    // 点的大小：1到10 
    $matrixPointSize = 10;  
    //创建一个二维码文件 
    QRcode::png($data,$filename2,$errorCorrectionLevel,$matrixPointSize,2);
    //QRcode::png($data); 
	return "/qrcode/".$filename.".png";
}


/*
 *
 *替换移动端内容字段图片路径
 *
 */
function replaceurl($newurl) 
{ 
 $newurl=preg_match("#^(http|https):\/\/#i","$newurl")? "$newurl" : str_replace('/uploads/',$GLOBALS['cfg_basehost'].'/uploads/',$newurl);
 return $newurl;
}

/*
 *
 *替换移动端内容字段图片路径
 *
 */
function replacewww($pcurl)
{
	$wapurl = str_replace('www.',  'm.', $pcurl);
	return $wapurl;
}

/**
 * 首页-获取图片
 */
function getImages($content){
    $preg = '/<img.*?src=[\"|\']?(.*?)[\"|\']?\s.*?>/i';//匹配img标签的正则表达式
    preg_match_all($preg, $content, $allImg);//这里匹配所有的img
    return $allImg[1][0];
}

//替换面包屑位置
function replacePosition($content){
    return str_replace($GLOBALS['cfg_indexname'], $GLOBALS['cfg_webname'], $content);
}

// 首页文章
if ( ! function_exists('getIndexArticle'))
{
    function getIndexArticle()
    {
        global $dsql;
        $sql = "SELECT * FROM `#@__archives` ORDER BY pubdate DESC LIMIT 3" ;
        $dsql->Execute('me',$sql);
        $i=1;
        $list="";
        while($row = $dsql->GetArray())
        {
            $arcurl = GetOneArchive($row['id'])['arcurl'];
            $list .= '<div class="home-news-item mb-4">
          <div class="row">
            <h4 class="col-10 col-xl-11 home-news-title ftw text-pc-lht ftz-m-title2">
              <a href="'.$arcurl.'" target="_blank">
                '.mb_strimwidth($row['title'], 0, 40, '...', 'utf8').'
              </a>
            </h4>
            <div class="home-news-num col-xl-1 col-2 text-right ftw ftz-m-title2">
              0'.$i.'.
            </div>
          </div>
        
          <p class="home-news-text pb-4 mt-20 ftz-m">
            <a href="xinwen/news2.html" target="_blank">'.mb_strimwidth($row['description'],0, 97, '...','utf8').'</a>
          </p>
        </div>';
            $i++;
        }
        return $list;
    }
}

//资讯分页
if(!function_exists('getArticleUrl')){
    function getArticleUrl($id, $type){
        global $dsql;
        if($type == 'pre'){
            $where = ' id > ' . $id;
            $order = ' asc';
        }elseif ($type == 'next'){
            $where = ' id < ' . $id;
            $order = ' DESC';
        }
        $res = $dsql->GetOne("SELECT id,title FROM `dede_archives` WHERE ".$where." ORDER BY id ". $order ." LIMIT 1");
        if(!empty($res)){
            $arcurl = GetOneArchive($res['id']);
            if(strpos($arcurl['arcurl'], 'plus/view.php') != FALSE){
                $arcurl = $arcurl['typedir'].'/'.$arcurl['id'].'.html';
            }else{
                $arcurl = $arcurl['arcurl'];
            }
            if($type == 'pre'){
                $html = '<a href="'.$arcurl.'" class="news-btn sub-p sub-m-p">上一篇：'.$res['title'].'</a>';
            }elseif ($type == 'next'){
                $html = '<a href="'.$arcurl.'" class="news-btn sub-p sub-m-p">下一篇：'.$res['title'].'</a>';
            }
        }else{
            if($type == 'pre'){
                $html = '<a href="javascript:void(0);" class="news-btn sub-p sub-m-p">上一篇：没有文章了</a>';
            }elseif ($type == 'next'){
                $html = '<a href="javascript:void(0);" class="news-btn sub-p sub-m-p">下一篇：没有文章了</a>';
            }
        }
        return $html;
    }
}



//替换域名（模板用）
if(!function_exists('replaceBasehost')){
    function replaceBasehost($temp){
        return $GLOBALS['cfg_basehost'];
    }
}